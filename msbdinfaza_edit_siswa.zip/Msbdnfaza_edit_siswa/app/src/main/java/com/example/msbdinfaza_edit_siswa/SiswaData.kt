package com.example.msbdinfaza_edit_siswa


data class SiswaData (var nis:String,
                      var nama:String,
                      var jekel:String
)